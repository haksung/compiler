int main ()
{
	int i;
	while (1)
	{
		i = i + 100;
	}

	return 0;
}
