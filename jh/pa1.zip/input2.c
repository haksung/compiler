int main ()
{
	int i;
	i = 2;

	if (i == 3)
	{
		i = 10 * i;
	}

	return 0;
}
