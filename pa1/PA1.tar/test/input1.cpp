int main() {
	int a;
	int b;
	int c = 0;

	a = -120;
	b = 150;
	c= -a*b +c;

	return (0);
}
