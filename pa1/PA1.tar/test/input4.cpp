int main() {
	int a;
	int b;
	int c = 0;

	if(c <= -1) {
		int d = 200;
		c = c + d;
	}

        a = (1 + 2) * 3 / (1 != 2);
        b = 1 == 2 * 3 < 4 + a / 2;


	do {
		a = 2;
		b = 3;
	} while ( a > 3);
}
